package com.learning.dev.srikar.chatting.Classes;

public class Chatlist {

    private String Sender, Receiver;

    public Chatlist(){}

    public String getSender() {
        return Sender;
    }

    public void setSender(String sender) {
        Sender = sender;
    }

    public String getReceiver() {
        return Receiver;
    }

    public void setReceiver(String receiver) {
        Receiver = receiver;
    }
}
